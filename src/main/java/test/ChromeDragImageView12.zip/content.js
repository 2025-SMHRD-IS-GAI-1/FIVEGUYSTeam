(function() {
  // 스크립트가 중복 실행되는 것을 방지
  if (window.hasCaptureScript) return;
  window.hasCaptureScript = true;

  let startPoint = null;
  
  // 1. 안내 메시지 박스 생성
  const messageBox = document.createElement('div');
  messageBox.textContent = '캡처할 영역의 시작 지점을 클릭하세요.';
  messageBox.style.cssText = `
    position: fixed;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    background: rgba(255, 255, 255, 0.95);
    color: #333;
    padding: 15px 25px;
    border-radius: 8px;
    box-shadow: 0 4px 12px rgba(0,0,0,0.2);
    font-size: 18px;
    font-weight: bold;
    z-index: 1000000;
    pointer-events: none; /* 클릭 통과 */
  `;
  document.body.appendChild(messageBox);

  // 2. 화면 전체를 덮는 반투명 오버레이 생성
  const overlay = document.createElement('div');
  overlay.style.cssText = `
    position: fixed;
    top: 0;
    left: 0;
    width: 100vw;
    height: 100vh;
    background: rgba(0, 0, 0, 0.3);
    cursor: crosshair;
    z-index: 999999; 
  `;
  document.body.appendChild(overlay);

  // 클릭 이벤트 리스너 추가
  overlay.addEventListener('click', (e) => {
    if (!startPoint) {
      // 첫 번째 클릭: 시작 좌표 저장
      startPoint = { x: e.clientX, y: e.clientY };
      
      const feedbackDot = document.createElement('div');
      feedbackDot.style.cssText = `
        position: fixed;
        left: ${e.clientX - 2}px;
        top: ${e.clientY - 2}px;
        width: 4px;
        height: 4px;
        background: red;
        border-radius: 50%;
        z-index: 1000000;
      `;
      overlay.appendChild(feedbackDot); 

      // 3. 안내 메시지 변경
      messageBox.textContent = '캡처할 영역의 종료 지점을 클릭하세요.';

    } else {
      // 두 번째 클릭: 종료 좌표 저장
      const endPoint = { x: e.clientX, y: e.clientY };

      const coords = {
        x: Math.min(startPoint.x, endPoint.x),
        y: Math.min(startPoint.y, endPoint.y),
        width: Math.abs(startPoint.x - endPoint.x),
        height: Math.abs(startPoint.y - endPoint.y)
      };

      // 4. 캡처 전 오버레이와 메시지 제거
      document.body.removeChild(overlay);
      document.body.removeChild(messageBox);
      window.hasCaptureScript = false;

      // 100ms 지연 후 캡처 메시지를 전송 (UI가 사라진 후 캡처하기 위함)
      setTimeout(() => {
        chrome.runtime.sendMessage({ type: 'capture', coords: coords });
      }, 100); 
    }
  }, { once: false });

})();

