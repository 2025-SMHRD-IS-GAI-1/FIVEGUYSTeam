// 1. 확장 프로그램 아이콘을 클릭했을 때 실행
chrome.action.onClicked.addListener((tab) => {
  // 현재 활성화된 탭에 content.js 파일을 주입(실행)
  chrome.scripting.executeScript({
    target: { tabId: tab.id },
    files: ['content.js']
  });
});

// 2. content.js로부터 메시지를 받았을 때 실행
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.type === 'capture') {
    
    // 현재 보이는 탭을 캡처
    chrome.tabs.captureVisibleTab(null, { format: 'png' }, (dataUrl) => {
      if (chrome.runtime.lastError) {
        console.error(chrome.runtime.lastError.message);
        return;
      }
      
      // 캡처한 이미지(dataUrl)와 좌표(request.coords)를 임시 저장
      chrome.storage.local.set({
        captureData: dataUrl,
        coords: request.coords
      }, () => {
        // capture.html 파일을 새 탭으로 열기
        chrome.tabs.create({ url: 'capture.html' });
      });
    });
    
    // 비동기 응답을 위해 true 반환
    return true; 
  }
});

